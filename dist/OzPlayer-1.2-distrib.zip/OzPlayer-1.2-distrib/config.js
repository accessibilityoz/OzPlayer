/*******************************************************************************
 Copyright (c) 2013 AccessibilityOz          http://www.accessibilityoz.com.au/
 ------------------------------------------------------------------------------
 OzPlayer [1.2] => configuration script
 ------------------------------------------------------------------------------
*******************************************************************************/
(function()
{


	//optionally re-define universal config 
	//nb. these examples are not required, they're just examples
	//(and all the sample values are the same as their defaults)
	OzPlayer.define("default-volume", 		0.7); 		//video and audio default volume (float from 0 to 1)
	OzPlayer.define("default-width", 		320); 		//default width if <video width> is not defined (pixels)
	OzPlayer.define("default-height", 		180); 		//default height if <video height> is not defined (pixels)
	OzPlayer.define("auto-hiding-delay", 	4); 		//auto-hiding delay for stack controls and skip links (float seconds, or zero to disable auto-hiding)
	
	
	
	//initialise a video player, passing the player ID
	//nb. you should initialse players as soon as possible after the markup
	//ie. don't wait for window.onload or DOMContentLoaded or whatever
	new OzPlayer.Video("demo");


})();