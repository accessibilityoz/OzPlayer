/*******************************************************************************
 Copyright (c) 2013 AccessibilityOz          http://www.accessibilityoz.com.au/
 ------------------------------------------------------------------------------
 OzPlayer [1.1] => interface language
 ------------------------------------------------------------------------------
*******************************************************************************/
(function(){var lang={
//----------------------------------------------------------------------------//


	//keyboard shortcuts help text 
	"keyboard-help-text"		: "<p>While focus is inside the player \u2014 press <kbd>Space</kbd> for Play or Pause.</p>"
								+ "<p>When focus is on a slider \u2014 press <kbd>Right/Left-Arrow</kbd> for fine control,"
								+ " <kbd>Page-Up/Down</kbd> for coarse control, or <kbd>Home/End</kbd> for min and max.</p>"

	
	//IMPORTANT => the keyboard shortcuts help text above is the ONLY language 
	//which is allowed to contain HTML -- all other strings must be plain text
	//for special characters you can use unicode escape-sequences, e.g. "\u2192"


	//form legend
	,"controls-legend"			: "Video Controls"
		
	//button aria-labels and tooltips
	,"button-playpause-off"		: "Play"
	,"button-playpause-on"		: "Pause"
	,"button-mute-off"			: "Unmute"
	,"button-mute-on"			: "Mute"
	,"button-cc-off"			: "Captions (OFF)"
	,"button-cc-on"				: "Captions (ON)"
	,"button-cc-loading"		: "Loading captions ..."
	,"button-cc-error"			: "Captions are not available"
	,"button-ad-off"			: "Audio Descriptions (OFF)"
	,"button-ad-on"				: "Audio Descriptions (ON)"
	,'button-ad-loading'		: 'Loading audio descriptions ...'
	,'button-ad-error'			: 'Audio descriptions are not available'
	,"button-fullscreen-off"	: "Fullscreen"
	,"button-fullscreen-on"		: "Exit Fullscreen"
	
	//button fallback text (e.g. when images are disabled)
	,"text-playpause-off"		: "Play"
	,"text-playpause-on"		: "Pause"
	,"text-mute-off"			: "Unmute"
	,"text-mute-on"				: "Mute"
	,"text-cc-off"				: "CC (off)"
	,"text-cc-on"				: "CC (on)"
	,"text-ad-off"				: "AD (off)"
	,"text-ad-on"				: "AD (on)"
	,"text-fullscreen-off"		: "Full"
	,"text-fullscreen-on"		: "Exit"
	
	//slider tooltips
	//n.b. the %1 tokens represent dynamic values, and can be the 
	//only value in the string if you don"t want the extra context
	//(e.g. for the volume slider to say "7" rather than "Volume: 7")
	,"slider-seek"				: "Time: %1"
	,"slider-volume"			: "Volume: %1"
	
	//skip and help link text
	,"skip-link-video"			: "Skip video"
	,"skip-link-transcript"		: "Skip to transcript"
	,"skip-link-shortcuts"		: "Keyboard shortcuts"
	
	//logo-bug link text
	,"logo-bug-text"			: "About OzPlayer"
	
	//video messages
	,"indicator-loading"		: "Buffering video ..."
	,"indicator-timeout"		: "Video failed to load."
	
	//transcript messagess
	,"transcript-loading"		: "Loading transcript ..."
	,"transcript-error"			: "Transcript is not available."
	,"transcript-end"			: "END OF TRANSCRIPT."
	

//----------------------------------------------------------------------------//
};for(var key in lang){OzPlayer.define("lang."+key,lang[key]);}})();