/*******************************************************************************
 Copyright (c) 2013 AccessibilityOz          http://www.accessibilityoz.com.au/
 ------------------------------------------------------------------------------
 OzPlayer => interface language
 ------------------------------------------------------------------------------
*******************************************************************************/
(function(){var lang={
//----------------------------------------------------------------------------//


	//form legend
	"controls-legend"			: "Video Controls"
		
	//button aria-labels and tooltips
	,"button-playpause-off"		: "Play"
	,"button-playpause-on"		: "Pause"
	,"button-mute-off"			: "Unmute"
	,"button-mute-on"			: "Mute"
	,"button-cc-off"			: "Captions (OFF)"
	,"button-cc-on"				: "Captions (ON)"
	,"button-cc-loading"		: "Loading captions ..."
	,"button-cc-error"			: "Captions are not available"
	,"button-ad-off"			: "Audio Descriptions (OFF)"
	,"button-ad-on"				: "Audio Descriptions (ON)"
	,'button-ad-loading'		: 'Loading audio descriptions ...'
	,'button-ad-error'			: 'Audio descriptions are not available'
	,"button-fullscreen-off"	: "Fullscreen"
	,"button-fullscreen-on"		: "Exit Fullscreen"
	
	//button fallback text (e.g. when images are disabled)
	,'text-playpause-off'		: 'Play'
	,'text-playpause-on'		: 'Pause'
	,'text-mute-off'			: 'Unmute'
	,'text-mute-on'				: 'Mute'
	,'text-cc-off'				: 'CC (off)'
	,'text-cc-on'				: 'CC (on)'
	,'text-ad-off'				: 'AD (off)'
	,'text-ad-on'				: 'AD (on)'
	,'text-fullscreen-off'		: 'Fullscreen'
	,'text-fullscreen-on'		: 'Exit'
	
	//slider tooltips
	//n.b. the %1 tokens represent dynamic values, and can be the 
	//only value in the string if you don't want the extra context
	//(e.g. for the volume slider to say "7" rather than "Volume: 7")
	,"slider-seek"				: "Time: %1"
	,"slider-volume"			: "Volume: %1"
	
	//status messages
	,"indicator-loading"		: "Buffering video ..."
	,"indicator-timeout"		: "Video failed to load."
	,"transcript-loading"		: "Loading transcript ..."
	,"transcript-error"			: "Transcript is not available."
	

//----------------------------------------------------------------------------//
};for(var key in lang){OzPlayer.define("lang."+key,lang[key]);}})();