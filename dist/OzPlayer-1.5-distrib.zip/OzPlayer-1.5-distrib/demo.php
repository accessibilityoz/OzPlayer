<!doctype html>
<html lang="en">
<head>
	
	<meta charset="utf-8" />

	<title>OzPlayer (Main Demo)</title>

	<!-- (general demo styles, not required for player to function) -->
	<style type="text/css">
		
		/* canvas */
		html, body
		{
			font:normal normal normal 100%/1.4 verdana,sans-serif;
	
			background:#fff;
			color:#000;
		}
		body
		{
			display:table;
			width:1%;
			margin:10px auto;
		}
		* html body
		{
			width:auto;
			margin:10px;
		}
		*+ html body
		{
			width:auto;
			margin:10px;
		}
		
		/* structural labels */
		h2.structural-label
		{
			position:absolute;
			left:-1000em;
		}
		
	</style>


	
	<!-- MediaElement library (this must be in the head) --> 
	<script src="./ozplayer-core/mediaelement.min.js" type="text/javascript"></script>
	
	<!-- required player + required highlights 
	     (these must go in order: player, highlights) -->
	<link rel="stylesheet" href="./ozplayer-core/ozplayer.min.css" media="all" type="text/css" />
	<!-- (select from blue, purple, pink, red, orange, yellow, green) -->
	<link rel="stylesheet" href="./ozplayer-skin/highlights-purple.css" media="all" type="text/css" />

	<!-- (sample transcript styles) -->
	<link rel="stylesheet" href="transcript.css" media="all" type="text/css" />
	
</head>
<body>


	<!-- player container
	     "id"						can be anything, but must the same as in the config script
	     "class"					must be "ozplayer"
	     "data-transcript"			optionally specifies the ID of the transcript container
									or omit the attribute entirely for no transcript
	     "data-controls"			either "stack" for superimposed controls, or "row" for a separate row
	-->
	<div id="demo" class="ozplayer" data-transcript="demo-transcript" data-controls="stack">
	
		<!-- video element
		     "width"				can be anything, or defaults to 400 if omitted 
		     "height"				can be anything, or defaults to 225 if omitted 
		     "poster"				optionally specifies the poster image 
		     "preload"				can be "none" (don't preload) or "auto" (do preload)
		     "controls"				must be "controls"
		-->
		<video width="640" height="360" poster="../poster.jpg" preload="none" controls="controls">
			
			<!-- one or more video sources
			     "src"				specifies the path to a video file
			     "type"				specifies the mime-type e.g. "video/mp4"
			     nb. for best browser support include both "mp4" and "webm"
			-->
			<source src="../video.mp4" type="video/mp4" />
			<source src="../video.webm" type="video/webm" />
			
			<!-- none or more caption/transcript language sources
			     "src"				specifies the path to a VTT or SRT file
			     "kind"				must be "captions"
			     "srclang"			specifies the ISO language code of the captions 
			     "default"			can be "default" to have captions enabled by default, 
			            			or omit the attribute entirely to have them off by default
			     n.b. if multiple languages are included then the user's language
			     will be used to decide which one of them to display
			-->
			<track src="../captions.vtt" kind="captions" srclang="en" default="default" />
			
			<!-- none or more additional transcript data sources
			     "src"				specifies the path to a VTT or SRT file
			     "kind"				must be "metadata"
			     "data-kind"		must be "transcript"
			     "srclang"			specifies the ISO language code of the data 
			     n.b. if multiple languages are included then the user's language
			     will be used to decide which one of them to display
			-->
			<track src="../transcript.vtt" kind="metadata" data-kind="transcript" srclang="en" />

			<!-- static fallback content (for when video sources are not supported)
			     can contain anything, but recommend including the poster as an <img>
			     plus a set of links to download the video and captions files
			     n.b. ensure that any CSS you define for the fallback content
			     is specified with a descendent selector from ".ozplayer-fallback"
			-->
			<div class="ozplayer-fallback">
				<img src="../poster.jpg" alt="" />
				<ul>
					<li><a href="../video.mp4"><cite>Name of Video</cite> (MP4)</a></li>
					<li><a href="../video.webm"><cite>Name of Video</cite> (WebM)</a></li>
					<li><a href="../captions.vtt"><cite>Name of Video</cite> (English Captions)</a></li>
				</ul>
			</div>
			
		</video>

		<!-- audio descriptions element
		     "data-default"			can be "default" to have descriptions enabled by default, 
			                		or omit the attribute entirely to have them off by default
		     "preload"				should be "none" to prevent preloading in unsupported browsers
		     						n.b. in supported browsers the video's preload setting will be used
		-->
		<audio data-default="default" preload="none">
			
			<!-- one or more audio sources 
				 "src"				specifies the path to an audio file
				 "type"				specifies the mime-type e.g. "audio/mp3"
				 n.b. for best browser support include both "mp3" and "ogg"
			-->
			<source src="../descriptions.mp3" type="audio/mp3" />
			<source src="../descriptions.ogg" type="audio/ogg" />
		
		</audio>

	</div>
	
	
	<!-- (structural label before the transcript) -->	
	<h2 class="structural-label">
		Video Transcript
	</h2>


	<!-- optional player transcript container
	     "id"						can be anything, but must be the same 
	     							as the player's "data-transcript" attribute
	     "class"					must be "ozplayer-transcript"
	-->
	<div id="demo-transcript" class="ozplayer-transcript">
	
		<!-- optional PHP transcript generator -->
		<?php
		
			//import the OzPlayer class
			require('./ozplayer-core/OzPlayer.php');
			
			//define the captions data as (language code => file path)
			$captions = array('en' => '../captions.vtt');
			
			//optionally define the additional transcript data the same way
			$transcript = array('en' => '../transcript.vtt');
			
			//now pass the captions and transcript data to the get_transcript method
			//which will load and parse the data and compile it into transcript markup
			OzPlayer::get_transcript($captions, $transcript);
	
		?>
		
	</div>







	<!-- required player + optional lang + required configuration  
	     (these should be at the end of the body, and must go in order: core, lang, configuration) -->
	<script src="./ozplayer-core/ozplayer.min.js" type="text/javascript"></script>
	<script src="./ozplayer-lang/en.js" type="text/javascript"></script>
	<script src="config.js" type="text/javascript"></script>
	

</body>
</html>