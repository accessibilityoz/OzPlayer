/*******************************************************************************
 Copyright (c) 2013-7 AccessibilityOz        http://www.accessibilityoz.com.au/
 ------------------------------------------------------------------------------
 OzPlayer [2.1] => batch configuration script
 ------------------------------------------------------------------------------
*******************************************************************************/
(function()
{


    //initialise all OzPlayer instances
    //n.b. you should initialise players as soon as possible after the markup
    //i.e. don't wait for window.onload or DOMContentLoaded or suchlike
    OzPlayer.init();


})();
